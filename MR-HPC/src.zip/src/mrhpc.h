/*
 * mrhpc.h
 *
 *  Created on: Feb 11, 2014
 *      Author: chung
 */

#ifndef MRHPC_H_
#define MRHPC_H_

#include <string>
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>

#include <mpi.h>
#include "Constants.h"

using std::string;
using namespace std;

class Mapper {
	int *rNodeList;
	int rNodeNumber;
public:
	virtual ~Mapper(){};
	virtual void Map(const string &key,const string &value) = 0;

	virtual void Emit(const string &key, const string &value);
	virtual void End();
	void initialize(int, int*);
};

class ReduceInput{
	vector<string> listKey;
	int jobID;

public:
	ReduceInput(int jobID);
	void addKeyValue(const string &key, const string &value);
	vector<string> getKeyValue(const string &key);
	virtual ~ReduceInput(){};
	vector<string> getListKey();
};

class Reducer{
	int mNodeNumber;
public:
	virtual ~Reducer(){};
	virtual void Reduce(const string &key, vector<string> value) = 0;
	void initialize(int);
	void wait();

	virtual void Emit(const string &value){};
};

class MR_JOB{
	int mNodeNumber;
	int rNodeNumber;
	int *rNodeList;
	string inputFile;
	Mapper *map;
	Reducer *reduce;
public:
	MR_JOB(int mNodeNumber, int rNodeNumber);
	virtual ~MR_JOB(){};
	void setM_Task(Mapper &m);
	void setR_Task(Reducer &r);
	int initialize();
	void startJob();
	void setInputFile(const string &filename);
	void readData();
};

class LIB{
public:
	static unsigned long long int getHash(const string str);
	static std::vector<std::string> split(const std::string &s, char delim);
	static std::vector<std::string> &split(const std::string &s, char delim, std::vector<std::string> &elems);
	static string convertInt(int number);
	static bool fileExist(const std::string name);
};

#endif /* MRHPC_H_ */
